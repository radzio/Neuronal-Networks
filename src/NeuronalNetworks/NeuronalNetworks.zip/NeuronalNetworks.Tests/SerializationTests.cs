﻿using NUnit.Framework;

namespace NeuronalNetwork.Tests
{
    [TestFixture]
    public class SerializationTests
    {
        [Test]
        public void TestMethod1()
        {
            //to do ;-)
        }
    }
}
